<?php
/**
 * Dokan Dashboard Reverse Withdrawal Header Template
 *
 * @since 3.5.1
 */
?>
<header class="dokan-dashboard-header">
    <h1 class="entry-title"><?php esc_html_e( 'Reverse Withdrawal', 'dokan-lite' ); ?></h1>
</header><!-- .dokan-dashboard-header -->
