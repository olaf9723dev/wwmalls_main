<?php

use WeDevs\Dokan\Abstracts\DokanRESTAdminController;

abstract class Dokan_REST_Admin_Controller extends DokanRESTAdminController {}
