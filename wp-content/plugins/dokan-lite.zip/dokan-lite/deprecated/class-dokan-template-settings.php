<?php

use WeDevs\Dokan\Dashboard\Templates\Settings;

class Dokan_Template_Settings extends Settings {}
