const defaultConfig = require('@wordpress/prettier-config');

module.exports = {
  ...defaultConfig,
  useTabs: false,
  tabWidth: 4,
  singleQuote: true,
}
