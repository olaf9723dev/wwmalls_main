<?php 
    // function add_vendor_category(){

        // <p class="form-row form-group form-row-wide">
        //     <label for="vendor_category">
        //         Vendor Category<br />
        //         <span class="required">*</span>
        //     </label>
        //     <input type="text" name="vendor_category" id="vendor_category" class="input"/>
        // </p>

//     }
//     add_action('register_form', 'add_vendor_category');
// 
?>