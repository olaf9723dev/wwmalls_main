<?php

<?php
/*
Plugin Name: My Shipping Method
Description: Custom shipping method for WooCommerce.
Version: 1.0
Author: Your Name
*/

// Ensure WooCommerce is active
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Register the shipping method
// add_action( 'woocommerce_shipping_init', 'wwmall_shipping_method_init' );

function wwmall_shipping_method_init() {
    if ( ! class_exists( 'WC_My_Shipping_Method' ) ) {
        class WC_Wwmall_Shipping_Method extends WC_Shipping_Method {
            public function __construct() {
                $this->id                 = 'wwmall_shipping_method';
                $this->method_title       = __( 'Wwmall Shipping Method', 'woocommerce' );
                $this->method_description = __( 'Wwmall shipping method for WooCommerce.', 'woocommerce' );
                $this->enabled            = 'yes';
                $this->title              = __( 'Wwmall Shipping Method', 'woocommerce' );

                $this->init();
            }

            public function init() {
                $this->instance_form_fields = include( 'includes/settings-wwmall-shipping-method.php' );
                $this->supports = array(
                    'shipping-zones',
                    'instance-settings',
                    'instance-settings-modal',
                );
            }

            public function calculate_shipping( $package = array() ) {
                // Calculate shipping costs here based on the package details
                $cost = 10; // Sample shipping cost

                $rate = array(
                    'id'    => $this->id,
                    'label' => $this->title,
                    'cost'  => $cost,
                );

                $this->add_rate( $rate );
            }
            
        	public function sanitize_cost( $value ) {
        		$value = is_null( $value ) ? '' : $value;
        		$value = wp_kses_post( trim( wp_unslash( $value ) ) );
        		$value = str_replace( array( get_woocommerce_currency_symbol(), html_entity_decode( get_woocommerce_currency_symbol() ) ), '', $value );
        		// Thrown an error on the front end if the evaluate_cost will fail.
        		$dummy_cost = $this->evaluate_cost(
        			$value,
        			array(
        				'cost' => 1,
        				'qty'  => 1,
        			)
        		);
        		if ( false === $dummy_cost ) {
        			throw new Exception( WC_Eval_Math::$last_error );
        		}
        		return $value;
        	}
        }
    }
}

// Add the shipping method to WooCommerce
function add_wwmall_shipping_method( $methods ) {
    $methods[] = 'WC_Wwmall_Shipping_Method';
    return $methods;
}
// add_filter( 'woocommerce_shipping_methods', 'add_wwmall_shipping_method' );
